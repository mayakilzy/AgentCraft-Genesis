# G7-Final-Release-Evidence

**Branch**: build/group-07-product-experience
**Base SHA (G6-09C)**: bff7b0a6f8b4e35880a9c7453d4e6de343e4e001
**G7-01 SHA**: c17b006
**G7-01 closure SHA**: 6132f82
**G7-02 SHA**: 9bf80c1
**G7-02 auth-gate fix SHA**: 81c07b5
**G7-03 SHA**: 30a84f3
**G7-04 SHA**: cce85db
**G7-05 SHA**: a2fdd9a
**G7-06 SHA**: (pending commit)

## Verdicts

- **G7_PRODUCT_DEVELOPMENT**: PASS — all 6 UI groups implemented against verified gateway contracts; 102/102 tests pass.
- **PRODUCTION_DEPLOYMENT**: INCONCLUSIVE — requires independent verification of the 5 G6-09C operational conditions (real ZAI/OpenBot providers, restart durability, shutdown idempotency, trusted extraEnv, Promise.race cleanup continuation). NOT verifiable in the controlled environment.

## Contents

- `evidence/g7/checkpoints/G7-01.json` through `G7-06.json` — recovery metadata
- `evidence/g7/screenshots/` — UI captures across viewports
- `scripts/g7-*` — all test scripts
- `web/` — full Next.js UI source

## How to reproduce

```bash
# From the repo root:
bun run lint                    # engine lint → 0 errors
cd web/ && bun run lint          # Next.js lint → 0 errors (if Next.js project at root)
# From Next.js project root:
npx tsx scripts/g7-01-closure-tests.ts         # 12/12
npx tsx scripts/g7-02-auth-gate-unit-tests.ts   # 20/20
npx tsx scripts/g7-02-auth-gate-tests.ts        # 14/14
npx tsx scripts/g7-02-e2e-submission.ts         # 8/8
npx tsx scripts/g7-04-artifacts-unit-tests.ts  # 20/20
npx tsx scripts/g7-04-artifacts-e2e-tests.ts   # 13/13
npx tsx scripts/g7-05-studio-unit-tests.ts      # 15/15
# Total: 102/102 PASS
```

## Controlled-environment limitations

- `GENESIS_EXECUTION_MODE=development` uses `MemoryComputer + DEVELOPMENT_REASONING_FALLBACK`. Real ZAI/OpenBot integration is NOT claimed.
- Cost (usd) is $0 in dev mode → shown as "Not measured" (NOT $0 success).
- No aggregation/metrics endpoint exists in gateway v1. Insights shows per-mission metrics only.
- Event stream is polling-based; 100-event cap per response. Replay does NOT imply complete history.
- INTEGRATED_EVIDENCE map for Studio is hardcoded from source inspection at pinned SHA bff7b0a.

## Independent review checklist

- [ ] Fresh git clone + npm install + bun run lint → 0 errors
- [ ] All 102 tests pass
- [ ] Verify the 5 G6-09C operational conditions with real providers
- [ ] Verify restart durability (gateway restart loses in-process state — documented)
- [ ] Verify shutdown idempotency + trusted extraEnv + Promise.race cleanup continuation
- [ ] Set GENESIS_OPERATOR_PIN to a strong random value (>= 32 chars) for production
- [ ] Set GENESIS_BFF_SECRET to a stable random value (>= 32 chars) for production
- [ ] Add rate limiting to /api/auth/login before any non-local deployment
- [ ] Verify CORS is constrained to same-origin (already enforced)
- [ ] Run security/secret-sentinel scan on the production build

Only after all checklist items pass: set PRODUCTION_DEPLOYMENT=PASS and deploy.
